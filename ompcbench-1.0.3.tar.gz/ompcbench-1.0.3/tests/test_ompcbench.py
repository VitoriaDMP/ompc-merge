def test_true():
    """A test that never fails."""
    assert True
