#!/usr/bin/env python

import os
from setuptools import setup, find_packages


def read(rel_path):
    here = os.path.abspath(os.path.dirname(__file__))
    with open(os.path.join(here, rel_path), "r") as fp:
        return fp.read()


def get_version(rel_path):
    for line in read(rel_path).splitlines():
        if line.startswith("__version__"):
            delim = '"' if '"' in line else "'"
            return line.split(delim)[1]
    else:
        raise RuntimeError("Unable to find version string.")


with open("requirements.txt", "r") as f:
    requirements = f.readlines()

# fmt: off
setup(
    # Metadata
    name = "ompcb-merge",
    version = get_version("ompcb/__init__.py"),
    description = "Merge timelines from OMPC",
    long_description = "",
    license = "",
    author = "Vitoria D. M. Pinho",
    author_email = "v188511@dac.unicamp.br",

    # Package configuration
    python_requires = ">=3.6, <4",
    packages = find_packages("."),
    project_urls = {
        "Bug Reports": "https://gitlab.com/ompcluster/ompcbench/issues",
        "Source": "https://gitlab.com/ompcluster/ompcbench"
    },

    # Entry points
    entry_points = {
        "console_scripts": [
            "ompcb-merge = ompcb.__main__:main",
        ]
    },

    # Dependency management
    install_requires = requirements,
)
